<?php

use App\Route; 

/*----------------------------------------------------Front---------------------------------------------------------*/ 

Route::get('/', 'MainController@index'); 












/*----------------------------------------------------Back---------------------------------------------------------*/ 




Route::get('/admin', 'AdminController@index');  
Route::get('/admin/sound', 'AdminController@soundList');
Route::get('/admin/sound/delete', 'AdminController@soundDelete');
Route::get('/admin/sound/store', 'AdminController@soundStore');
Route::post('/admin', 'AdminController@store');  
Route::get('/clients', 'AdminController@clients');  
Route::get('/test', 'AdminController@test');  
Route::post('/test', 'AdminController@tst');  
Route::post('/admin/firstTimetable', 'AdminController@firstTimetable');  
Route::post('/admin/secondTimetable', 'AdminController@secondTimetable');  














$REQUEST_URI = explode('?', $_SERVER['REQUEST_URI'])[0];
if(!in_array($REQUEST_URI, Route::$routes))
{
  $base_url="http://".$_SERVER['SERVER_NAME'].'/';
  include "../resources/views/errors/404.php";
}

?>