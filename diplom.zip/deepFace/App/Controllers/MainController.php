<?php

namespace App\Controllers;

// use App\Models\Appointment;
// use App\Models\Client;
// use App\Models\Doctor;

class MainController extends Controller
{

    public $template = '../resources/views/front/';

    public function index()
    {  
        include $this->template.'index.php';
    }



}
?>