<?php
namespace App\Controllers;
use App\Helpers\HeaderClass;

class Controller
{
  public $template = '../resources/views/';
  public $Base_url;

  public function __construct()
  {
    session_start();
    $this->Base_url="http://".$_SERVER['SERVER_NAME'].'/';
    date_default_timezone_set('Asia/Bishkek');
    
  }


  public function ddie($data)
  {
    echo '<pre>';
    var_dump($data);
    echo '</pre>';
    die();
  }
}
?>