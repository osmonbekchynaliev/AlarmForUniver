<?php

namespace App\Controllers;

use App\Models\Occasion;
use App\Models\FTime;
use App\Models\STime;
use App\Models\Sound;
use App\Models\SoundOccasion;

class AdminController extends Controller
{

    public $template = '../resources/views/back/';

    public function index()
    {
        $fTime = FTime::getInstance()->get();
        $sTime = STime::getInstance()->get();
        $occasions = Occasion::getInstance()->get();
        $soundOcca = SoundOccasion::getInstance()->get();
        $sounds = Sound::getInstance()->get();

        include $this->template . 'index.php';
    }

    public function store()
    {
        $result = '';
        $i = 0;
        $up_dir = "back/sounds/";
        $tmpName = $_FILES["file"]["tmp_name"];
        $Name = basename($_FILES["file"]["name"]);
        move_uploaded_file($tmpName, $up_dir . "$Name");
        Sound::getInstance()->create(['path' => $_FILES["file"]["name"]]);
        $sounds = Sound::getInstance()->get();
        foreach ($sounds as $sound) {
            $i += 1;
            $result .= '<tr>
                <th scope="row">' . $i . '</th>
                <td>' . $sound["path"] . '</td>
                <td>' . $sound["upTime"] . '</td>
                <td class="fs-5">
                    <audio class="audio">
                        <source src="back/sounds/' . $sound["path"] . '" type="audio/mpeg">
                    </audio>
                    <i class="bi text-danger me-1 bi-play-circle-fill btn-play" role="button"></i>
                    <i class="bi bi-trash text-danger me-1 btn-del" role="button"></i>
                    <button type="button" class="btn btn-primary">Выбрать</button>
                </td>
            </tr>';
        }
        echo $result;
    }

    public function soundList()
    {
        $id = $_GET['occasion'];
        $sounds = Sound::getInstance()->get();
        $occasions = Occasion::getInstance()->where('id', $id)->first();
        include $this->template . 'soundList.php';
    }

    public function soundDelete()
    {
        $id = $_GET['id'];
        $redirect_id = $_GET['occasion'];
        Sound::getInstance()->delete($id);
        header("Location: /admin/sound?occasion=$redirect_id");
    }

    public function soundStore()
    {
        $redirect_id = $_GET['occasion'];
        $id = $_GET['id'];
        $oc_id = SoundOccasion::getInstance()->where('occasion_id', $redirect_id)->first();
        if (isset($oc_id)){
            SoundOccasion::getInstance()->where('occasion_id',$redirect_id)->update([
                'occasion_id' => $redirect_id,
                 'sound_id' => $id
                ]);
        } else {
            SoundOccasion::getInstance()->create(['occasion_id' => $redirect_id, 'sound_id' => $id]);
        }
        header("Location: /admin/sound?occasion=$redirect_id");
    }

    public function create()
    {
        $t1 = "08:00";
        $t2 = "08:50";
        list($hours1, $minutes1) = explode(":", $t1);
        list($hours2, $minutes2) = explode(":", $t2);
        $total1 = $hours1 * 60 + $minutes1;
        $total2 = $hours2 * 60 + $minutes2;
        // $total_minutes = $hours * 60 + $minutes;
        // $new_total = $total_minutes + 50; 
        // $new_minutes = $new_total % 60;
        // $new_hours = floor($new_total / 60);
        // $new_hours = $new_hours % 24;
        // $new_time = "$new_hours:$new_minutes";
        $id = 0;

        function newMin($start, $duration)
        {
            list($hours, $minutes) = explode(":", $start);
            $total_minutes = $hours * 60 + $minutes;
            $new_total = $total_minutes + $duration;
            $new_minutes = $new_total % 60;
            $new_hours = floor($new_total / 60);
            $new_hours = $new_hours % 24;
            $endTime = "$new_hours:$new_minutes";
            return $endTime;
        }



        $firstTime = FTime::getInstance()->get();
        include $this->template . 'doc/create.php';
    }

    public function firstTimetable()
    {
        $start = $_POST['start'];
        $free = $_POST['free'];
        $duration = $_POST['duration'];
        $bigFree = $_POST['bigFree'];
        $bigTime = $_POST['bigTime'];
        $count = $_POST['count'];
        $freeTime = 0;
        $FtimeExist = FTime::getInstance()->get();
        if ($FtimeExist) {
            FTime::getInstance()->truncate();
        }
        for ($i = 1; $i <= $count; $i++) {
            $endLess = date('H:i', strtotime($start . "+$duration minutes"));
            if ($i == $bigTime) {
                $freeTime = $bigFree;
                // echo "$i - урок | Start - $start | End - $endLess | FreeTime - $freeTime | <br>";
                FTime::getInstance()->create([
                    'sTime' => $start,
                    'dTime' => $duration,
                    'fTime' => $freeTime,
                    'eTime' => $endLess
                ]);
                $total = $duration + $freeTime;
                $start = date('H:i', strtotime($start . "+$total minutes"));
                $endLess = date('H:i', strtotime($start . "+$duration minutes"));
            } else {
                $freeTime = $free;
                // echo "$i - урок | Start - $start | End - $endLess | FreeTime - $freeTime | <br>";
                FTime::getInstance()->create([
                    'sTime' => $start,
                    'dTime' => $duration,
                    'fTime' => $freeTime,
                    'eTime' => $endLess
                ]);
                $total = $duration + $freeTime;
                $start = date('H:i', strtotime($start . "+$total minutes"));
                $endLess = date('H:i', strtotime($start . "+$duration minutes"));
            }
        }
    }

    public function secondTimetable()
    {
        $start = $_POST['start'];
        $free = $_POST['free'];
        $duration = $_POST['duration'];
        $bigFree = $_POST['bigFree'];
        $bigTime = $_POST['bigTime'];
        $count = $_POST['count'];
        $freeTime = 0;
        $STimeExist = STime::getInstance()->get();
        if ($STimeExist) {
            STime::getInstance()->truncate();
        }
        for ($i = 1; $i <= $count; $i++) {
            $endLess = date('H:i', strtotime($start . "+$duration minutes"));
            if ($i == $bigTime) {
                $freeTime = $bigFree;
                // echo "$i - урок | Start - $start | End - $endLess | FreeTime - $freeTime | <br>";
                STime::getInstance()->create([
                    'sTime' => $start,
                    'dTime' => $duration,
                    'fTime' => $freeTime,
                    'eTime' => $endLess
                ]);
                $total = $duration + $freeTime;
                $start = date('H:i', strtotime($start . "+$total minutes"));
                $endLess = date('H:i', strtotime($start . "+$duration minutes"));
            } else {
                $freeTime = $free;
                // echo "$i - урок | Start - $start | End - $endLess | FreeTime - $freeTime | <br>";
                STime::getInstance()->create([
                    'sTime' => $start,
                    'dTime' => $duration,
                    'fTime' => $freeTime,
                    'eTime' => $endLess
                ]);
                $total = $duration + $freeTime;
                $start = date('H:i', strtotime($start . "+$total minutes"));
                $endLess = date('H:i', strtotime($start . "+$duration minutes"));
            }
        }
    }

    public function test()
    {
        include $this->template . 'test.php';
    }
    public function tst()
    {
        $start = $_POST['start'];
        $free = $_POST['free'];
        $duration = $_POST['duration'];
        $bigFree = $_POST['bigFree'];
        $bigTime = $_POST['bigTime'];
        $count = $_POST['count'];
        $freeTime = 0;
        $FtimeExist = FTime::getInstance()->get();
        if ($FtimeExist) {
            FTime::getInstance()->truncate();
        }
        for ($i = 1; $i <= $count; $i++) {
            $endLess = date('H:i', strtotime($start . "+$duration minutes"));
            if ($i == $bigTime) {
                $freeTime = $bigFree;
                // echo "$i - урок | Start - $start | End - $endLess | FreeTime - $freeTime | <br>";
                FTime::getInstance()->create([
                    'sTime' => $start,
                    'dTime' => $duration,
                    'fTime' => $freeTime,
                    'eTime' => $endLess
                ]);
                $total = $duration + $freeTime;
                $start = date('H:i', strtotime($start . "+$total minutes"));
                $endLess = date('H:i', strtotime($start . "+$duration minutes"));
            } else {
                $freeTime = $free;
                // echo "$i - урок | Start - $start | End - $endLess | FreeTime - $freeTime | <br>";
                FTime::getInstance()->create([
                    'sTime' => $start,
                    'dTime' => $duration,
                    'fTime' => $freeTime,
                    'eTime' => $endLess
                ]);
                $total = $duration + $freeTime;
                $start = date('H:i', strtotime($start . "+$total minutes"));
                $endLess = date('H:i', strtotime($start . "+$duration minutes"));
            }
        }
    }
}
