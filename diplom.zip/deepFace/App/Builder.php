<?php

namespace App;

use mysqli;

class Builder extends Database{

    public $table;
    private $where;

    public function get()
    {
        $result = mysqli_query($this->connect, "SELECT * FROM $this->table $this->where");
        return mysqli_fetch_all($result,MYSQLI_ASSOC);
    }

    public function truncate()
    {
        mysqli_query($this->connect, "TRUNCATE $this->table");
    }

    
    public function getDesc()
    {
        $result = mysqli_query($this->connect, "SELECT * FROM $this->table ORDER BY id DESC");
        return mysqli_fetch_all($result,MYSQLI_ASSOC);
    }

    public function getAll($query)
    {
        $result = mysqli_query($this->connect,$query);
        return mysqli_fetch_all($result,MYSQLI_ASSOC);
    }

    public function first()
    {
        $result = mysqli_query($this->connect, "SELECT * FROM $this->table $this->where");
        return mysqli_fetch_row($result);
    }

    public function create($data){
        foreach ($data as $key => $value){
            $colums .= $key.",";
            $values .= "'$value',";
        }
        $colums = rtrim($colums, ',');
        $values = rtrim($values, ',');
        mysqli_query($this->connect, "INSERT INTO $this->table ($colums) VALUES ($values)");
    }

    public function delete($id)
    {
        $id = $_GET['id'];
        mysqli_query($this->connect, "DELETE FROM $this->table WHERE id=$id");
    }

    public function where($key, $value)
    {
        $this->where = "WHERE ".$key." = '".$value."'";
        return $this;
    }

    public function whereMulti($value)
    {
        $this->where = "WHERE ".$value;
        return $this;
    }

    public function whereAll($key, $value)
    {
        $result = mysqli_query($this->connect, "SELECT * FROM $this->table WHERE $key = '$value'");
        return mysqli_fetch_all($result);
    }

    public function update($data)
    {
        $values = '';
        foreach ($data as $key => $value)
        {
            $values .= " $key = '$value',";
        }
        $values = rtrim($values, ',');
        mysqli_query($this->connect, "UPDATE $this->table SET $values $this->where");
    }
}