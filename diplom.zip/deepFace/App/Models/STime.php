<?php

namespace App\Models;

use App\Builder;

Class STime extends Builder {

    public $table = 'stime';
    static $instance;

    static public function getInstance(){
        if(is_null(self::$instance)){
            self::$instance = new self();
        }
        return self::$instance;
    }

}