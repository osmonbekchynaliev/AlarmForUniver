<?php
    namespace App\Helpers;

    class HeaderClass
    {
        static $instance;

        static public function getInstance()
        {
            if(is_null(self::$instance))
            {
                self::$instance = new self();
            }
            
            return self::$instance;
        }

        public function addTime($t, $m)
        {
            $time = $t;
            $add = $m;
            list($hours,$minutes) = explode(":",$time);
            $total_minutes = $hours * 60 + $minutes;
            $new_total = $total_minutes + $add; 
            $new_minutes = $new_total % 60;
            $new_hours = floor($new_total / 60);
            $new_hours = $new_hours % 24;
            $new_time = "$new_hours:$new_minutes";
            return $new_time;
        }

    }
?>