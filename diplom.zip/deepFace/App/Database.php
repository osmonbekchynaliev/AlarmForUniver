<?php

namespace App;

abstract class Database {

    public $connect;

    function __construct()
    {
        $this->connect = mysqli_connect('localhost', 'root', '', 'diplom');

        // $this->connect = mysqli_connect('localhost', 'root', '', 'wave');
         
        if (mysqli_connect_errno())
        {
          echo "Failed to connect to MySQL: " . mysqli_connect_error();
          exit();
        }
    }

    abstract function get();
    abstract function where($key, $value);
    abstract function create($data);
    abstract function whereAll($key, $value);

}