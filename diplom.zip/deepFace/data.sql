-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.7.33 - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Version:             11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for diplom
CREATE DATABASE IF NOT EXISTS `diplom` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `diplom`;

-- Dumping structure for table diplom.ftime
CREATE TABLE IF NOT EXISTS `ftime` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sTime` varchar(10) DEFAULT NULL,
  `dTime` varchar(50) DEFAULT NULL,
  `fTime` varchar(50) DEFAULT NULL,
  `eTime` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- Dumping data for table diplom.ftime: ~6 rows (approximately)
/*!40000 ALTER TABLE `ftime` DISABLE KEYS */;
INSERT INTO `ftime` (`id`, `sTime`, `dTime`, `fTime`, `eTime`) VALUES
	(1, '08:00', '50', '10', '08:50'),
	(2, '09:00', '50', '10', '09:50'),
	(3, '10:00', '50', '30', '10:50'),
	(4, '11:20', '50', '10', '12:10'),
	(5, '12:20', '50', '10', '13:10'),
	(6, '13:20', '50', '10', '14:10');
/*!40000 ALTER TABLE `ftime` ENABLE KEYS */;

-- Dumping structure for table diplom.isactived
CREATE TABLE IF NOT EXISTS `isactived` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `occasion_id` varchar(30) NOT NULL,
  `sound_id` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- Dumping data for table diplom.isactived: ~6 rows (approximately)
/*!40000 ALTER TABLE `isactived` DISABLE KEYS */;
INSERT INTO `isactived` (`id`, `occasion_id`, `sound_id`) VALUES
	(1, '1', '3'),
	(2, '2', '2'),
	(3, '3', '4'),
	(4, '5', '1'),
	(5, '4', '140'),
	(6, '6', '141');
/*!40000 ALTER TABLE `isactived` ENABLE KEYS */;

-- Dumping structure for table diplom.occasion
CREATE TABLE IF NOT EXISTS `occasion` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `img` text,
  `slug` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- Dumping data for table diplom.occasion: ~6 rows (approximately)
/*!40000 ALTER TABLE `occasion` DISABLE KEYS */;
INSERT INTO `occasion` (`id`, `name`, `img`, `slug`) VALUES
	(1, 'Пожар', 'fire.png', NULL),
	(2, 'Гимн', 'gimn.png', NULL),
	(3, 'Земл-ние', 'earthquake.png', NULL),
	(4, 'Звонок', 'ad.png', 'zvonok'),
	(5, 'ЧП', 'emergency.png', NULL),
	(6, 'Собрание', 'meeting.png', NULL);
/*!40000 ALTER TABLE `occasion` ENABLE KEYS */;

-- Dumping structure for table diplom.sounds
CREATE TABLE IF NOT EXISTS `sounds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `path` text NOT NULL,
  `upTime` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=143 DEFAULT CHARSET=utf8;

-- Dumping data for table diplom.sounds: ~7 rows (approximately)
/*!40000 ALTER TABLE `sounds` DISABLE KEYS */;
INSERT INTO `sounds` (`id`, `path`, `upTime`) VALUES
	(1, 'zhu.mp3', '2022-05-30 19:44:30'),
	(2, 'gimn-kirgizii.mp3', '2022-05-30 19:47:00'),
	(3, 'fire.mp3', '2022-05-30 19:54:30'),
	(4, 'chp.mp3', '2022-05-30 20:33:34'),
	(140, 'muzykal-nyy-shkol-nyy-zvonok-bez-nazvaniya.mp3', '2022-06-06 18:13:16'),
	(141, 'shkol-nyy-zvonok-dzz.mp3', '2022-06-07 18:27:33'),
	(142, 'shkolnyiy-zvonok-36976.mp3', '2022-06-07 18:30:00');
/*!40000 ALTER TABLE `sounds` ENABLE KEYS */;

-- Dumping structure for table diplom.stime
CREATE TABLE IF NOT EXISTS `stime` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sTime` varchar(10) NOT NULL DEFAULT '"13:30"',
  `dTime` varchar(50) NOT NULL DEFAULT '0',
  `fTime` varchar(50) NOT NULL DEFAULT '0',
  `eTime` varchar(50) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- Dumping data for table diplom.stime: ~6 rows (approximately)
/*!40000 ALTER TABLE `stime` DISABLE KEYS */;
INSERT INTO `stime` (`id`, `sTime`, `dTime`, `fTime`, `eTime`) VALUES
	(1, '14:39', '50', '10', '15:29'),
	(2, '15:39', '50', '10', '16:29'),
	(3, '16:39', '50', '10', '17:29'),
	(4, '17:39', '50', '10', '18:29'),
	(5, '18:39', '50', '10', '19:29'),
	(6, '19:39', '50', '10', '20:29');
/*!40000 ALTER TABLE `stime` ENABLE KEYS */;

-- Dumping structure for table diplom.times
CREATE TABLE IF NOT EXISTS `times` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` varchar(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- Dumping data for table diplom.times: ~9 rows (approximately)
/*!40000 ALTER TABLE `times` DISABLE KEYS */;
INSERT INTO `times` (`id`, `value`) VALUES
	(1, '08:00'),
	(2, '08:30'),
	(3, '09:00'),
	(4, '09:30'),
	(5, '10:00'),
	(6, '10:30'),
	(7, '13:00'),
	(8, '13:30'),
	(9, '14:00');
/*!40000 ALTER TABLE `times` ENABLE KEYS */;

-- Dumping structure for table diplom.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `token` text NOT NULL,
  `password` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table diplom.users: ~0 rows (approximately)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
