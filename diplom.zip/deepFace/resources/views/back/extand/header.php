<!doctype html>
<html lang="ru">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.2/font/bootstrap-icons.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Play&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">

    <style>
        .table tbody tr.highlight td {
            background-color: #ddd;
        }

        * {
            font-family: 'Play', sans-serif;
        }

        .disabled {
            cursor: not-allowed;
            pointer-events: none;
            opacity: 0.5;
        }

        .success__text {
            margin: 1rem 0;
            color: green;
            text-align: center;
        }
    </style>
</head>

<body class="user-select-none">

    <?php if ($_SERVER['REQUEST_URI'] == '/admin') : ?>
        <header class="container-fluid py-4 ">
            <div class="d-flex align-items-center justify-content-between">
                <h5>Тема: Автоматизация системы звонков ВУЗа на входе и выходе</h5>
                <h2 class="my-2 fs-4 text-primary" id="clock">00:00:00 KG</h2>
                <h2 class="my-2 fs-4 text-muted">Автор: Чыналиев Осмонбек</h2>
            </div>
        </header>
    <?php else : ?>
        <header class="container-fluid py-4 ">
            <div class="d-flex align-items-center justify-content-between">
                <a href="/admin"> <button class="btn btn-outline-primary"><i class="bi bi-arrow-bar-left"></i> Назад</button></a>
                <h5>Тема: Автоматизация системы звонков ВУЗа на входе и выходе</h5>
                <h2 class="my-2 fs-4 text-muted">Автор: Чыналиев Осмонбек</h2>
            </div>
        </header>
    <?php endif ?>