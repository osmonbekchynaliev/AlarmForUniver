<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script>
    $(document).ready(function() {
        $("#firstTimetable").click(function() {
            var start = $("#start").val();
            var free = $("#free").val();
            var duration = $("#duration").val();
            var bigFree = $("#bigFree").val();
            var bigTime = $("#bigTime").val();
            var count = $("#count").val();
            // Returns successful data submission message when the entered information is stored in database.
            var dataString = 'start=' + start + '&free=' + free + '&duration=' + duration + '&bigFree=' + bigFree + '&bigTime=' + bigTime + '&count=' + count;
            if (start == '' || free == '' || duration == '' || bigFree == '' || bigTime == '' || count == '') {
                alert("Please Fill All Fields");
            } else {
                // AJAX Code To Submit Form.
                $.ajax({
                    type: "POST",
                    url: "/admin/firstTimetable",
                    data: dataString,
                    cache: false,
                    success: function(result) {
                        document.getElementById('first-edit').textContent = 'Успешно отправлено'
                        setTimeout(() => {
                            document.getElementById('first-edit').textContent = ''
                        }, 3000)
                    }
                });
            }
            return false;
        });

    });
</script>
<script>
    $(document).ready(function() {
        $("#secondTimetable").click(function() {
            var start = $("#Sstart").val();
            var free = $("#Sfree").val();
            var duration = $("#Sduration").val();
            var bigFree = $("#SbigFree").val();
            var bigTime = $("#SbigTime").val();
            var count = $("#Scount").val();
            // Returns successful data submission message when the entered information is stored in database.
            var dataString = 'start=' + start + '&free=' + free + '&duration=' + duration + '&bigFree=' + bigFree + '&bigTime=' + bigTime + '&count=' + count;
            if (start == '' || free == '' || duration == '' || bigFree == '' || bigTime == '' || count == '') {
                alert("Please Fill All Fields");
            } else {
                // AJAX Code To Submit Form.
                $.ajax({
                    type: "POST",
                    url: "/admin/secondTimetable",
                    data: dataString,
                    cache: false,
                    success: function(result) {
                        document.getElementById('second-edit').textContent = 'Успешно отправлено'
                        setTimeout(() => {
                            document.getElementById('second-edit').textContent = ''
                        }, 3000)
                    }
                });
            }
            return false;
        });
    });
</script>
<script>
    $("#files").change(function() {
        var formData = new FormData();
        formData.append('file', $("#files")[0].files[0]);
        $.ajax({
            type: "POST",
            url: '/admin',
            cache: false,
            contentType: false,
            processData: false,
            data: formData,
            success: function(msg) {
                $('#data-d').html(msg)
                document.querySelector('#message').textContent = "Удача! Вы отправили на сервер, новый сигнал!";
                setTimeout(() => {
                    location.reload();
                    document.querySelector('#message').textContent = '';
                }, 1000)
            }
        });
    });
    // Удача! Вы отправили на сервер, новый сигнал!
    $('#infoTable').on('click', 'tbody tr', function(event) {
        $(this).addClass('highlight').siblings().removeClass('highlight');
    });


    let myVar = setInterval(myTimer, 1000);

    function myTimer() {
        let d = new Date();
        let t = d.toLocaleTimeString();
        $("#clock").html(t);
    }


    var audio = document.querySelectorAll('.audio');
    var playPauseBTN = document.querySelectorAll('.btn-play');
    var delBtn = document.querySelectorAll('.btn-del');
    var count = 0;

    function playPause(i) {
        if (count == 0) {
            count = 1;
            playPauseBTN.forEach((el, idx) => {
                el.classList.add('disabled')
                delBtn[idx].classList.add('disabled')
            })
            audio[i].play();
            playPauseBTN[i].classList.remove('bi-play-circle-fill')
            playPauseBTN[i].classList.remove('disabled')
            playPauseBTN[i].classList.add('bi-pause-circle-fill')
        } else {
            count = 0;
            playPauseBTN.forEach((el, idx) => {
                el.classList.remove('disabled')
                delBtn[idx].classList.remove('disabled')
                audio[i].currentTime = 0;
            })
            audio[i].pause();
            playPauseBTN[i].classList.remove('bi-pause-circle-fill')
            playPauseBTN[i].classList.add('bi-play-circle-fill')
        }

    }

    function stop(i) {
        playPause(i)
        audio[i].pause();
        audio[i].currentTime = 0;
        playPauseBTN.innerHTML = "Play ►";
    }


    audio.forEach((_, idx) => {
        playPauseBTN[idx].addEventListener('click', () => playPause(idx))
    })
</script>

<script>
    var audioIndex = document.querySelectorAll('.audio__index');
    var playPauseBTNIndex = document.querySelectorAll('.btn__play__index');
    var countIndex = 0;

    function playPauseIndex(i) {
        if (countIndex == 0) {
            countIndex = 1;
            playPauseBTNIndex.forEach((el, idx) => {
                el.classList.add('disabled')
            })
            audioIndex[i].play();
            playPauseBTNIndex[i].classList.remove('disabled')
        } else {
            countIndex = 0;
            playPauseBTNIndex.forEach((el, idx) => {
                el.classList.remove('disabled')
                audioIndex[i].currentTime = 0;
            })
            audioIndex[i].pause();
        }

    }

    function stop(i) {
        playPauseIndex(i)
        audioIndex[i].pause();
        audioIndex[i].currentTime = 0;
        playPauseBTNIndex.innerHTML = "Play ►";
    }


    audioIndex.forEach((_, idx) => {
        playPauseBTNIndex[idx].addEventListener('click', () => playPauseIndex(idx))
    })
</script>

<script>
    let startTimes = document.querySelectorAll('.start__time')
    let endTimes = document.querySelectorAll('.end__time')
    let counterTimes = document.querySelectorAll('.counterTime')
    var getTimeLocal = new Date()

    let timeLesson = `${getTimeLocal.getHours()}:${getTimeLocal.getMinutes()}`.split(":")
    let currentMinute = Math.floor((Number(timeLesson[0]) * 60) + Number(timeLesson[1]))

    setInterval(function() {
        getTimeLocal = new Date()
        currentMinute = Math.floor((Number(timeLesson[0]) * 60) + Number(timeLesson[1]))
        timeLesson = `${getTimeLocal.getHours()}:${getTimeLocal.getMinutes()}`.split(":")

    }, 1000)




    startTimes.forEach((el, index) => {
        const arrEl = el.textContent.split(':')
        const getStartTime = (Number(arrEl[0]) * 60) + Number(arrEl[1])
        let endTimeLesson = endTimes[index].textContent.split(':')
        let getEndTime = Number(endTimeLesson[0] * 60) + Number(endTimeLesson[1])

        let isVisible = getStartTime < currentMinute && getEndTime > currentMinute

        if (isVisible) {

            counterTimes[index].parentNode.classList.add('bg-success')
            counterTimes[index].parentNode.classList.add('text-white')

            setInterval(() => {
                const currSeconds = 60 - new Date().getSeconds()
                $(counterTimes[index]).html(
                    getEndTime - currentMinute ?
                    `${getEndTime - currentMinute} мин. ${ currSeconds < 10 ? `0${currSeconds}` : currSeconds } сек.` :
                    `${getEndTime - currentMinute} мин. 00 сек.`
                )


                if (getStartTime === currentMinute || getEndTime === currentMinute) {
                    const zvon = document.querySelector('.zvonok')
                    if (new Date().getSeconds() < 6 && currSeconds > 56) {
                        zvon.play()
                        setTimeout(() => {
                            zvon.pause()
                        }, 5000)
                    }
                }

                if (currSeconds == 55 && getEndTime == currentMinute) {
                    location.reload()
                }

            }, 1000)

        } else {
            $(counterTimes[index]).html('<h3>∞</h3>')
        }


    })

    console.log()
</script>
</body>

</html>