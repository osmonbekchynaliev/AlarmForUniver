<div class="modal modal-lg fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Выберите сигнал</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <table class="table" id="infoTable">
                    <thead>
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Название</th>
                            <th scope="col">Дата создание</th>
                            <th scope="col">Действие</th>
                        </tr>
                    </thead>
                    <tbody id="data-d">
                        <!-- data -->
                        <?php echo $result?>
                        <!-- data -->

                    </tbody>
                </table>
            </div>
            <div class="modal-footer flex-nowrap justify-content-between">
                <span></span>
                <span id="message" class="font-weight-lighter text-success"></span>
                <div class="d-flex">
                    <div class="d-block mx-1">
                        <form action="" method="POST" enctype="multipart/form-data">
                        <input type="file" class="form-control visually-hidden" name="files" id="files" accept="audio/mp3">
                        <!-- <input type="file" class="form-control" name="file" accept="audio/mp3">
                        <button type="submit">Send</button> -->
                        <label for="files" class="btn btn-outline-primary">Добавить</label>
                        </form>
                    </div>
                    <button type="button" class="btn btn-primary">Выбрать</button>
                </div>
            </div>
        </div>
    </div>
</div>
