<div class="accordion-item">
    <h2 class="accordion-header" id="headingTwo">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
            <h2 class="w-100 text-center my-1"> 2-СМЕНА</h2>
        </button>
    </h2>
    <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample1">
        <div class="accordion-body">
                <div class="success__text" id="second-edit"></div>
            <form action="" method="POST">
                <div class="input-group my-2 w-50">
                    <span class="input-group-text w-50">Начало 2-смены</span>
                    <input type="time" value="13:20" id="Sstart" name="start" class="form-control">
                </div>
                <div class="input-group my-2 w-50">
                    <span class="input-group-text w-50">Количество уроков</span>
                    <input type="number" value="6" id="Scount" name="count" class="form-control">
                </div>
                <div class="input-group my-2 w-50">
                    <span class="input-group-text w-70">Продолжительность обычной перемены</span>
                    <input type="number" value="10" id="Sfree" name="free" class="form-control">
                </div>
                <div class="input-group my-2 w-50">
                    <span class="input-group-text w-70">Продолжительность урока</span>
                    <input type="number" value="50" id="Sduration" name="duration" class="form-control">
                </div>
                <div class="input-group my-2 w-50">
                    <span class="input-group-text w-70">Продолжительность большой перемены</span>
                    <input type="number" value="10" id="SbigFree" name="bigFree" class="form-control">
                </div>
                <div class="input-group my-2 w-50">
                    <span class="input-group-text w-70">Большая перемена</span>
                    <input type="number" class="form-control" id="SbigTime" name="bigTime" placeholder="После какого урока?">
                </div>

                <button class="btn btn-primary" id="secondTimetable">Сохранить</button>
            </form>
        </div>
    </div>
</div>