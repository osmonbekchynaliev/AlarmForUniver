<div class="accordion-item">
    <h2 class="accordion-header" id="headingOne">
        <button class="accordion-button" type="button" data-bs-toggle="collapse"
        data-bs-target="#collapseOne" aria-expanded="true"
        aria-controls="collapseOne">
        <h2 class="w-100 text-center my-1"> 1-СМЕНА</h2>
    </button>
</h2>
<div id="collapseOne" class="accordion-collapse collapse show"
aria-labelledby="headingOne" data-bs-parent="#accordionExample">
<div class="accordion-body">
    <div class="d-block">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th class="text-center" scope="col">Урок</th>
                    <th class="text-center" scope="col">Начало</th>
                    <th class="text-center" scope="col">Конец</th>
                    <th class="text-center" scope="col">Перемена</th>
                    <th class="text-center" scope="col">Осталось</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($fTime as $time):?>
                    <tr>
                    <th class="text-center" scope="row"><?php echo $time['id']; ?></th>
                    <td class="start__time text-center"><?php echo $time['sTime']; ?></td>
                    <td class="end__time text-center"><?php echo $time['eTime']; ?></td>
                    <td class="free__time text-center"><?php echo $time['fTime']; ?></td>
                    <td class="counterTime text-center">50 мин.</td>
                </tr>
                <?php endforeach?>
                
            </tbody>
        </table>
    </div>
</div>
</div>
</div>