<div class="accordion-item">
    <h2 class="accordion-header" id="headingOne">
        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
            <h2 class="w-100 text-center my-1"> 1-СМЕНА</h2>
        </button>
    </h2>
    <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample1">
        <div class="accordion-body">
            <div class="success__text" id="first-edit"></div>
            <form action="" method="POST">
                <div class="input-group my-2 w-50">
                    <span class="input-group-text w-50">Начало 1-смены</span>
                    <input type="time" value="08:00" id="start" name="start" class="form-control">
                </div>
                <div class="input-group my-2 w-50">
                    <span class="input-group-text w-50">Количество уроков</span>
                    <input type="number" value="6" id="count" name="count" class="form-control">
                </div>
                <div class="input-group my-2 w-50">
                    <span class="input-group-text w-70">Продолжительность обычной перемены</span>
                    <input type="number" value="10" id="free" name="free" class="form-control">
                </div>
                <div class="input-group my-2 w-50">
                    <span class="input-group-text w-70">Продолжительность урока</span>
                    <input type="number" value="50" id="duration" name="duration" class="form-control">
                </div>
                <div class="input-group my-2 w-50">
                    <span class="input-group-text w-70">Продолжительность большой перемены</span>
                    <input type="number" value="30" id="bigFree" name="bigFree" class="form-control">
                </div>
                <div class="input-group my-2 w-50">
                    <span class="input-group-text w-70">Большая перемена</span>
                    <input type="number" class="form-control" id="bigTime" name="bigTime" placeholder="После какого урока?">
                </div>

                <button class="btn btn-primary" id="firstTimetable">Сохранить</button>
            </form>
        </div>
    </div>
</div>