<div class="row gap-3">
    <?php foreach ($occasions as $key => $occasion) : ?>
        <div class="col-5 my-4">
            <label for="formFileSm" class="form-label text-secondary">
                <h3>Выберите сигнал: <span class="text-info"><?php echo $occasion['name'] ?></span></h3>
            </label>
            <div class="row">
                <div class="col-8 d-flex align-items-center">
                    <a href="/admin/sound?occasion=<?php echo $occasion['id']; ?>"><button class="btn btn-primary me-3" data-bs-toggle="modal" data-bs-target="#staticBackdrop">Выбрать</button></a>
                    <?php foreach ($soundOcca as $name) : ?>
                        <?php if ($name['occasion_id'] == $occasion['id']) : ?>
                            <?php foreach ($sounds as $sound) : ?>
                                <?php if ($sound['id'] == $name['sound_id']) : ?>
                                    <span class="mx-1 align-content-center border-bottom"><?php echo $sound['path']; ?></span>
                                <?php endif ?>
                            <?php endforeach ?>
                        <?php endif ?>
                    <?php endforeach ?>
                </div>
                <div class="col-4">
                    <img src="back/img/<?php echo $occasion['img']; ?>" alt="" class="img-fluid" width="100px">
                </div>
            </div>
        </div>
    <?php endforeach ?>
</div>