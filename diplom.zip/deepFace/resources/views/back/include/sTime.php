<div class="accordion-item">
    <h2 class="accordion-header" id="headingTwo">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
            <h2 class="w-100 text-center my-1">2-СМЕНА</h2>
        </button>
    </h2>
    <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
        <div class="accordion-body">
            <div class="d-block">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th class="text-center" scope="col">Урок</th>
                            <th class="text-center" scope="col">Начало</th>
                            <th class="text-center" scope="col">Конец</th>
                            <th class="text-center" scope="col">Перемена</th>
                            <th class="text-center" scope="col">Осталось</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($sTime as $time) : ?>
                            <tr>
                                <th class="text-center" scope="row"><?php echo $time['id']; ?></th>
                                <td class="start__time text-center"><?php echo $time['sTime']; ?></td>
                                <td class="end__time text-center"><?php echo $time['eTime']; ?></td>
                                <td class="free__time text-center"><?php echo $time['fTime']; ?></td>
                                <td class="counterTime text-center">50 мин.</td>
                            </tr>
                        <?php endforeach ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>