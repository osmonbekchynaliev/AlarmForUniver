<center>
<form action="/test" method="POST">
    <div class="input-group my-2 w-50">
        <span class="input-group-text w-50">Начало 1-смены</span>
        <input type="time" value="08:00" id="start" name="start" class="form-control">
    </div>
    <div class="input-group my-2 w-50">
        <span class="input-group-text w-50">Количество  уроков</span>
        <input type="number" value="6" id="count" name="count" class="form-control">
    </div>
    <div class="input-group my-2 w-50">
        <span class="input-group-text w-70">Продолжительность обычной перемены</span>
        <input type="number" value="10" id="free" name="free" class="form-control">
    </div>
    <div class="input-group my-2 w-50">
        <span class="input-group-text w-70">Продолжительность урока</span>
        <input type="number" value="50" id="duration" name="duration" class="form-control">
    </div>
    <div class="input-group my-2 w-50">
        <span class="input-group-text w-70">Продолжительность большой перемены</span>
        <input type="number" value="0" id="bigFree" name="bigFree" class="form-control">
    </div>
    <div class="input-group my-2 w-50">
        <span class="input-group-text w-70">Большая перемена</span>
        <input type="number" class="form-control" id="bigTime" name="bigTime" placeholder="После какого урока?">
    </div>

    <button class="btn btn-primary" id="firstTimetable">Сохранить</button>
</form>
</center>