<? include "../resources/views/back/extand/app.php"; ?> 

<div class="container">
  <div class="block-header block-header-default">
    <h3 class="block-title">Текущее расписание | До оканчание урока осталось : <span id="demo">00:00</span> </h3>



    
  </div>
  <span><?php
  $date = date('h:i');

?></span>
    <span id="ccc"></span>
<br>
  </span>
  <table class="table table-striped table-borderless table-vcenter">
    <thead>
      <tr class="bg-body-dark">
        <th style="width: 200px;">№</th>
        <th>Начало</th>
        <th>Конец</th>
        <th>Перемена</th>
      </tr>
    </thead>
    <tbody>
      <?foreach ($firstTime as $v):?>
      <tr <?php if ($fir>$date): ?>
        style="color:red;"
      <?php endif ?>>
        <td>
          <? 
          echo $id+=1;
          ?>
        </td>
        <td>
          <? $fir = date("H:i",strtotime($v[1]));
          echo $fir;?>
        </td>
        <td>
          <?
          echo $this->addTime($v[1],$v[2]);?>
        </td>
        <td>
          <? echo $v[3];?>
        </td>
      </tr>

      <?endforeach?>
    </tbody>
  </table> 
</div>
<!-- <script>
   var countDownDate = <?php echo strtotime($this->addTime($v[1],$v[2]) ) ?> * 1000;
   var countDate = <?php echo strtotime($v[1]) ?> * 1000;
   var now = <?php echo time() ?> * 1000;
    // Update the count down every 1 second
    var x = setInterval(function() {
      now = now + 1000;
    // Find the distance between now an the count down date
    var distance = countDownDate - now;
    // Time calculations for days, hours, minutes and seconds
    var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((distance % (1000 * 60)) / 1000);
    // Output the result in an element with id="demo"
    if (countDate>distance<countDownDate) {
      document.getElementById("demo").innerHTML = minutes + " м. " + ": " + seconds + " с. " ;
    }else{
      clearInterval(x);
      document.getElementById("demo").innerHTML = "ПЕРЕМЕНА";
    }
  }, 1000);

    var time = countDate;
    var date = new Date(+time * 1000);
    var h, m, s;
    h = date.getHours();
    m = date.getMinutes();
    s = date.getSeconds();
    var correct_date = h + ':' + m + ':' + s;

    console.log(correct_date);
</script> -->
<script>
  setInterval(function () {

            let date = new Date()

            let hours = (date.getHours() < 10) ? '0' + date.getHours() : date.getHours()

            let minutes = (date.getMinutes() < 10) ? '0' + date.getMinutes() : date.getMinutes();

            let seconds = (date.getSeconds() < 10) ? '0' + date.getSeconds() : date.getSeconds();

            let res = minutes > 50 ? 'Переменна' : `${50 - minutes}:${seconds} калды`;

            document.getElementById("ccc").innerHTML = res;
        }, 1000);
</script>
