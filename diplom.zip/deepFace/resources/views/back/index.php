<?php include "extand/header.php"; ?>
<main>
    <div class="container-fluid">
        <ul class="nav nav-tabs mb-2" id="myTab" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true"><i class="bi bi-house-door"></i> Главная</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false"><i class="bi bi-volume-up"></i> Настройка звука</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#contact" type="button" role="tab" aria-controls="contact" aria-selected="false"><i class="bi bi-calendar-date"></i> Изменить
                    расписаний</button>
            </li>
        </ul>
        <div class="tab-content" id="myTabContent">
            <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                <div class="row">
                    <div class="col-8">
                        <div class="accordion" id="accordionExample">

                            <!----------------first timetable-------->
                            <?php include "include/fTime.php"; ?>
                            <!----------------end first timetable-------->

                            <!----------------second timetable------ -->
                            <?php include "include/sTime.php"; ?>
                            <!----------------end second timetable------ -->
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="row gap-2 my-1">
                            <?php foreach ($occasions as $occasion) : ?>
                                <div class="col-5 btn btn-light fs-4 btn__play__index">
                                    <div><img src="back/img/<?php echo $occasion['img']; ?>" alt="" id="player" class="img-fluid" width="140px"></div>
                                    <?php echo $occasion['name']; ?>
                                    <?php foreach ($soundOcca as $active) : ?>
                                        <?php if ($active['occasion_id'] == $occasion['id']) : ?>
                                            <?php foreach ($sounds as $sound) : ?>
                                                <?php if ($sound['id'] == $active['sound_id']) : ?>
                                                    <audio class="audio__index <?php echo $occasion['slug']; ?>">
                                                        <source src="../back/sounds/<?php echo $sound["path"]; ?>" type="audio/mpeg">
                                                    </audio>
                                                <?php endif ?>
                                            <?php endforeach ?>
                                        <?php endif ?>
                                    <?php endforeach ?>
                                </div>
                            <?php endforeach ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                <!-- soundEdit -->
                <?php include "include/soundEdit.php"; ?>
                <!-- end soundEdit -->

                <!-- Modal -->

                <!-- end Modal -->

            </div>
            <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
                <div class="accordion" id="accordionExample1">
                    <!----------------first editor-------->
                    <?php include "include/fEdit.php"; ?>
                    <!----------------end first editor-------->

                    <!----------------second editor------ -->
                    <?php include "include/sEdit.php"; ?>
                    <!----------------end second editor------ -->

                </div>
            </div>
        </div>
    </div>
</main>
<?php include "extand/footer.php"; ?>