<? include "../resources/views/back/extand/app.php"; ?> 

<div class="content content-full">
  <div class="block">
    <div class="block-header block-header-default">
      <h3 class="block-title">Список докторов</h3>
    </div>
    <div class="block-content">
      <table class="table table-striped table-borderless table-vcenter">
        <thead>
          <tr class="bg-body-dark">
            <th style="width: 60px;">№</th>
            <th >Фотография</th>
            <th style="width: 33%;">Имя</th>
            <th style="width: 33%;">Действие</th>
          </tr>
        </thead> 
        <tbody>
          <?foreach ($occasion as $key => $new):?>
          <tr>
            <td>
              <?echo $i+=1;?>
            </td>
            <td>
              <?php if (!isset($new[2])): ?>
                <i>нет фото</i>
              <?php endif ?>
              <a href="/back/img/doctors/<?echo $new[2];?>" target="_blank">
                <img src="/back/img/doctors/<?echo $new[2];?>" alt="" width="50px" style="border-radius: 50%;">
              </a>
            </td>
            <td >
             <?echo $new[1];?>
           </td>
           <td >
             <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop" data-bs-whatever="@mdo">Указать музыку</button>
             <button class="btn btn-warning text-white">Прослушать музыку</button>

           </td>
         </tr>
         <?endforeach?>
       </tbody>
     </table>
   </div>
 </div>
</div>
</div>


<!-- Modal -->
<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-fullscreen">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Выберите музыку для звонка</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <table class="table table-striped table-borderless table-vcenter">
          <thead>
            <tr class="bg-body-dark">
              <th style="width: 60px;">№</th>
              <th style="width: 33%;">Имя</th>
              <th style="width: 33%;">Действие</th>
            </tr>
          </thead> 
          <tbody>
            <?foreach ($sounds as $new):?>
               <?php if (file_exists("{$Base_url}back/img/upload_dir/".$new[1])): ?>
            <tr>
              <td>
                <?echo $j+=1;?>
                <input name = "id" value="<? echo $new[0]?>" class="visually-hidden message">
              </td>
              <td >
               <?echo $new[1];?>
             </td>
             <td >
               <button class="btn btn-warning text-white soundalert">Выбрать</button>
                <button class="btn btn-primary text-white playPauseBTN">Возпроизвести ▶︎</button>
            </td>
          </tr>
          <audio class="audio">
            <source src="/back/img/upload_dir/<?echo $new[1];?>" type="audio/mpeg">
            </audio>
              <?php endif ?>
            <?endforeach?>
          </tbody>
        </table>
      </div>
      <div class="modal-footer">
        <label for="file" class="btn btn-primary">Загрузить новую музыку</label>
        <input type="file" id="file" name="file" style="display:none;">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Закрыть окно</button>
        
      </div>
    </div>
  </div>
</div>

 <script>
    var btns = document.querySelectorAll('.playPauseBTN');
    var audio = document.querySelectorAll('.audio');
    var count = 0;
    function playPause(idx){
        if(count == 0){
            btns.forEach( (item,id) =>{ 
                if(idx === id) {
                    item.classList.remove("disabled")
                }else{
                    item.classList.add("disabled")
                }
            })
            btns[idx].classList.add("active");
            count = 1;
            audio[idx].play();
            btns[idx].innerHTML = "Stop ⏸";
        }else{
            count = 0;
            audio[idx].pause();
            btns[idx].classList.remove("active");
            btns.forEach( item => item.classList.remove("disabled"))
            audio[idx].currentTime = 0;
            btns[idx].innerHTML = "Возпроизвести ▶︎";
        }
    }
    btns.forEach((btn,id)=>{
        btn.addEventListener("click", ()=>{
            playPause(id)

        })

    })
    
</script> 
<? include "../resources/views/back/extand/footer.php"; ?> 
