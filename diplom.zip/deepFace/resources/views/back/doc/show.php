<? include "../resources/views/back/extand/app.php"; ?> 

<div class="content content-full">
  <div class="block">
    <div class="block-header block-header-default">
      <h3 class="block-title">Список докторов</h3>
    </div>
    <div class="block-content">
      <table class="table table-striped table-borderless table-vcenter">
        <thead>
          <tr class="bg-body-dark">
            <th style="width: 60px;">№</th>
            <th >Фотография</th>
            <th style="width: 33%;">Имя</th>
          </tr>
        </thead>
        <tbody>
          <?foreach ($occasion as $key => $new):?>
          <tr>
            <td>
              <?echo $i+=1;?>
            </td>
            <td>
              <?php if (!isset($new[2])): ?>
                <i>нет фото</i>
              <?php endif ?>
              <a href="/back/img/doctors/<?echo $new[2];?>" target="_blank">
                <img src="/back/img/doctors/<?echo $new[2];?>" alt="" width="50px" style="border-radius: 50%;">
              </a>
            </td>
            <td >
             <?echo $new[1];?>
           </td>
         </tr>
         <?endforeach?>
       </tbody>
     </table>
   </div>
 </div>
</div>
</div>
