<? include "../resources/views/admin/app/header.php"; ?> 
<!-- Hero -->
        <div class="bg-body-light">
          <div class="content content-full">
            <div class="d-flex flex-column flex-sm-row justify-content-sm-between align-items-sm-center">
              <h1 class="flex-grow-1 fs-3 fw-semibold my-2 my-sm-3">Редактировать новость</h1>
            </div>
          </div>
        </div>
        <!-- END Hero -->

        <!-- Page Content -->
        <div class="content content-full content-boxed">
          <!-- New Post -->
          <form action="/DashBoard/news/update" method="POST" enctype="multipart/form-data">
            <div class="block">
              <div class="block-header block-header-default">
                <a class="btn btn-alt-secondary" href="/DashBoard/menu">
                  <i class="fa fa-arrow-left me-1"></i> Список новостей
                </a>
              <input type="text" class="visually-hidden" id="dm-post-edit-id" name="id" value="<?echo $news[0]?>" readonly>
              </div>
              <div class="block-content">
                <div class="row justify-content-center push">
                  <div class="col-md-10">
                    <div class="mb-4">
                      <label class="form-label" for="dm-post-add-title">Название на кыргызском</label>
                      <input type="text" name="title_kg" class="form-control" id="dm-post-add-title" value="<?echo $news[1]?>"  placeholder="Название на кыргызском..">
                    </div>
                    <div class="mb-4">
                      <label class="form-label" for="dm-post-add-title">Название на русском</label>
                      <input type="text" name="title_ru" class="form-control" id="dm-post-add-title" value="<?echo $news[2]?>"  placeholder="Название на русском..">
                    </div>
                    
                    <div class="mb-4">
                      <label class="form-label">Текст на кыргызском</label>
                      <textarea id="kg"  name="text_kg"><?echo $news[3]?></textarea>
                    </div>
                    <div class="mb-4">
                      <label class="form-label">Текст на русском</label>
                      <textarea id="ru"  name="text_ru"><?echo $news[4]?></textarea>
                    </div>
                    <div class="row mb-4">
                      <div class="col-xl-6">
                        <label class="form-label" for="dm-post-add-image">Изображение</label>
                        <input class="form-control" type="file" name="img" id="dm-post-add-image">
                      </div>
                    </div>
                       <img src="<?echo $this->Base_url;?>img/news/<?echo $news[6];?>" width="200px">                   
                </div>
              </div>
              <div class="block-content bg-body-light">
                <div class="row justify-content-center push">
                  <div class="col-md-10">
                    <button type="submit" name="submit" class="btn btn-alt-primary">
                      <i class="fa fa-fw fa-check opacity-50 me-1"></i> Сохранить изменение
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </form>
          <!-- END New Post -->
        </div>
        <!-- END Page Content -->
<? include "../resources/views/admin/app/footer.php"; ?> 
