<?php include "extand/header.php"; ?>
<div class="container mt-4">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title mb-4" id="staticBackdropLabel">Выберите сигнал для : <span class="text-info"><?php echo $occasions[1];?></span></h5>
        </div>
        <div class="modal-body">
            <table class="table" id="infoTable">
                <thead>
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Название</th>
                        <th scope="col">Дата создание</th>
                        <th scope="col">Действие</th>
                    </tr>
                </thead>
                <tbody id="data-d">
                    <!-- data -->
                    <?php $i = 0; ?>
                    <?php foreach ($sounds as $sound) : ?>
                        <tr>
                            <th scope="row"><?php echo $i += 1; ?></th>
                            <td><?php echo $sound["path"]; ?></td>
                            <td><?php echo $sound["upTime"]; ?></td>
                            <td class="fs-5">
                                <audio class="audio">
                                    <source src="../back/sounds/<?php echo $sound["path"]; ?>" type="audio/mpeg">
                                </audio>
                                <i class="bi text-danger me-1 bi-play-circle-fill btn-play" role="button"></i>
                                <a href="/admin/sound/delete?id=<?php echo $sound["id"];?>&occasion=<?php echo $occasions[0];?>"><i class="bi bi-trash text-danger me-1 btn-del" role="button"></i></a>
                                <a href="/admin/sound/store?id=<?php echo $sound["id"];?>&occasion=<?php echo $occasions[0];?>"><button type="button" class="btn btn-primary">Выбрать</button></a>
                            </td>
                        </tr>
                    <?php endforeach ?>
                    <!-- data -->
                </tbody>
            </table>
        </div>
        <div class="modal-footer flex-nowrap justify-content-between">
            <span></span>
            <span id="message" class="font-weight-lighter text-success"></span>
            <div class="d-flex">
                <div class="d-block mx-1">
                    <form action="" method="POST" enctype="multipart/form-data">
                        <input type="file" class="form-control visually-hidden" name="files" id="files" accept="audio/mp3">
                        <label for="files" class="btn btn-outline-primary" >Добавить 100%</label>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include "extand/footer.php"; ?>