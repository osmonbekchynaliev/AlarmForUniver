<? include "extand/header.php"; ?>
<? include "content.php"; ?>
<? include "extand/footer.php"; ?>  